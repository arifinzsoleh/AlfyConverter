plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.alfy.converter"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.alfy.converter"
        minSdk = 29
        targetSdk = 34
        versionCode = 11
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // agar APK release langsung bisa diinstall (tanpa keystore sendiri)
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-min:8.1.7")
}
