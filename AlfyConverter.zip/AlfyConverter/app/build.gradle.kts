plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.alfy.converter"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.alfy.converter"
        minSdk = 29
        targetSdk = 34
        versionCode = 10
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // agar APK release langsung bisa diinstall (tanpa keystore sendiri)
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.arthenica:ffmpeg-kit-min:6.0-2.LTS")
}
