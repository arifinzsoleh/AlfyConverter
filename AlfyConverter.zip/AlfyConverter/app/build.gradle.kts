plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.alfy.converter"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.alfy.converter"
        minSdk = 29
        targetSdk = 34
        versionCode = 7
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // agar APK release langsung bisa diinstall (tanpa keystore sendiri)
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // Fallback engine (transcode audio / codec yang tidak bisa di-remux langsung)
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
}
