package com.alfy.converter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/** Konversi murni FFmpeg: concat file .ts lalu `-c copy -bsf:a aac_adtstoasc` ke MP4. */
class MainActivity : Activity() {

    private class Cancelled : Exception("Dibatalkan")

    private var picked: List<Pair<Uri, String>> = emptyList()
    @Volatile private var cancelled = false
    private var busy = false

    private lateinit var btnPick: Button
    private lateinit var btnConvert: Button
    private lateinit var btnCancel: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        setContentView(R.layout.activity_main)
        btnPick = findViewById(R.id.btnPick)
        btnConvert = findViewById(R.id.btnConvert)
        btnCancel = findViewById(R.id.btnCancel)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        btnPick.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, REQ_PICK)
        }
        btnConvert.setOnClickListener { convert() }
        btnCancel.setOnClickListener {
            cancelled = true
            FFmpegKit.cancel()
            status.text = "Membatalkan..."
        }
        showPreviousCrash()
    }

    // ---------------------------------------------------------------- pilih file

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val list = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) list.add(clip.getItemAt(i).uri)
        } else {
            data.data?.let { list.add(it) }
        }
        picked = list.map { it to nameOf(it) }
            .sortedWith { a, b -> naturalCompare(a.second, b.second) }
        status.text = if (picked.isEmpty()) "Belum ada file dipilih"
        else "${picked.size} file dipilih:\n" + picked.joinToString("\n") { it.second }
    }

    private fun nameOf(u: Uri): String = try {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: u.lastPathSegment ?: "file"
    } catch (_: Exception) { u.lastPathSegment ?: "file" }

    private fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val x = re.findAll(a).map { it.value }.toList()
        val y = re.findAll(b).map { it.value }.toList()
        for (i in 0 until minOf(x.size, y.size)) {
            val p = x[i]; val q = y[i]
            val r = if (p[0].isDigit() && q[0].isDigit()) {
                val d = p.toBigInteger().compareTo(q.toBigInteger())
                if (d != 0) d else p.length.compareTo(q.length)
            } else p.compareTo(q)
            if (r != 0) return r
        }
        return x.size.compareTo(y.size)
    }

    private fun sizeOf(u: Uri): Long = try {
        contentResolver.openFileDescriptor(u, "r")?.use { it.statSize } ?: 0L
    } catch (_: Exception) { 0L }


    // ---------------------------------------------------------------- konversi

    private fun convert() {
        if (busy) return
        if (picked.isEmpty()) { status.text = "Pilih file .ts dulu"; return }
        setBusy(true)
        val src = picked.map { it.first }
        val name = picked.first().second.substringBeforeLast('.', "hasil_gabungan")
            .ifBlank { "hasil_gabungan" } + ".mp4"
        status.text = "Memproses (FFmpeg)..."
        progress.progress = 0

        Thread {
            val ins = mutableListOf<File>()
            val tmpOut = File(cacheDir, "hasil_gabungan.mp4")
            var outUri: Uri? = null
            try {
                tmpOut.delete()
                var total = 0L
                for ((i, u) in src.withIndex()) {
                    val f = File(cacheDir, "in_$i.ts")
                    ins.add(f)
                    contentResolver.openInputStream(u)!!.use { a ->
                        f.outputStream().use { o ->
                            val buf = ByteArray(1024 * 1024)
                            while (true) {
                                if (cancelled) throw Cancelled()
                                val n = a.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                            }
                        }
                    }
                    total += f.length()
                }
                total = total.coerceAtLeast(1L)
                FFmpegKitConfig.enableStatisticsCallback { s ->
                    val pct = (s.size * 100 / total).toInt().coerceIn(0, 99)
                    runOnUiThread { progress.progress = pct }
                }
                val input = if (ins.size == 1) ins[0].absolutePath
                else "concat:" + ins.joinToString("|") { it.absolutePath }
                val session = FFmpegKit.execute(
                    "-y -i \"$input\" -c copy -bsf:a aac_adtstoasc \"${tmpOut.absolutePath}\""
                )
                if (cancelled || ReturnCode.isCancel(session.returnCode)) throw Cancelled()
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    finish("Gagal: " + (session.allLogsAsString ?: "").takeLast(1500))
                    return@Thread
                }
                outUri = newOutput(name)
                contentResolver.openOutputStream(outUri, "w")!!.use { o ->
                    tmpOut.inputStream().use { it.copyTo(o) }
                }
                publishOutput(outUri)
                finish("Berhasil: Download/$name")
            } catch (e: Cancelled) {
                outUri?.let { deleteOutput(it) }
                finish("Dibatalkan")
            } catch (e: Throwable) {
                Log.w(TAG, "convert gagal", e)
                outUri?.let { deleteOutput(it) }
                finish("Gagal: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                ins.forEach { it.delete() }
                tmpOut.delete()
            }
        }.start()
    }

    private fun setBusy(b: Boolean) {
        busy = b
        btnPick.isEnabled = !b
        btnConvert.isEnabled = !b
        btnCancel.isEnabled = b
        if (b) { cancelled = false; window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun finish(msg: String, done: Boolean = true) = runOnUiThread {
        if (done && msg.startsWith("Berhasil")) progress.progress = 100
        status.text = msg
        setBusy(false)
    }

    // ---------------------------------------------------------------- output (MediaStore)

    private fun newOutput(name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Gagal membuat file di Downloads")
    }

    private fun publishOutput(u: Uri) {
        val v = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        contentResolver.update(u, v, null, null)
    }

    private fun deleteOutput(u: Uri) { try { contentResolver.delete(u, null, null) } catch (_: Exception) {} }

    // ---------------------------------------------------------------- crash logger

    private fun installCrashLogger() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            try { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(e)) } catch (_: Throwable) {}
            prev?.uncaughtException(th, e)
        }
    }

    private fun showPreviousCrash() {
        try {
            val f = File(filesDir, "crash.txt")
            if (f.exists()) {
                status.text = "Crash sebelumnya:\n" + f.readText().take(1500)
                f.delete()
            }
        } catch (_: Throwable) {}
    }


    companion object {
        private const val TAG = "AlfyConverter"
        private const val REQ_PICK = 1
    }
}
