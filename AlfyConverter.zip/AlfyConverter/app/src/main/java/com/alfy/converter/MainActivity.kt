package com.alfy.converter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.nio.ByteBuffer

/**
 * Alur konversi:
 *  1. UTAMA  : remux (MediaExtractor -> MediaMuxer). Video/audio disalin apa adanya ke MP4
 *              (tanpa re-encode) => cepat, kualitas tetap, hemat baterai.
 *  2. CADANGAN: Media3 Transformer, dipakai bila remux tidak bisa (mis. audio MP2/AC3, video MPEG-2)
 *              -> audio di-encode ke AAC.
 *  File dibaca langsung dari URI dan ditulis langsung ke Downloads (tanpa salinan sementara
 *  untuk mode remux), jadi aman untuk file berukuran besar.
 */
@UnstableApi
class MainActivity : Activity() {

    private class Unsupported(msg: String) : Exception(msg)
    private class Cancelled : Exception("Dibatalkan")

    private var picked: List<Pair<Uri, String>> = emptyList()
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var cancelled = false
    private var busy = false

    private lateinit var btnPick: Button
    private lateinit var btnConvert: Button
    private lateinit var btnCancel: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        setContentView(R.layout.activity_main)
        btnPick = findViewById(R.id.btnPick)
        btnConvert = findViewById(R.id.btnConvert)
        btnCancel = findViewById(R.id.btnCancel)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        btnPick.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, REQ_PICK)
        }
        btnConvert.setOnClickListener { convert() }
        btnCancel.setOnClickListener {
            cancelled = true
            transformer?.cancel()
            status.text = "Membatalkan..."
        }
        showPreviousCrash()
    }

    // ---------------------------------------------------------------- pilih file

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val list = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) list.add(clip.getItemAt(i).uri)
        } else {
            data.data?.let { list.add(it) }
        }
        picked = list.map { it to nameOf(it) }
            .sortedWith { a, b -> naturalCompare(a.second, b.second) }
        status.text = if (picked.isEmpty()) "Belum ada file dipilih"
        else "${picked.size} file dipilih:\n" + picked.joinToString("\n") { it.second }
    }

    private fun nameOf(u: Uri): String = try {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: u.lastPathSegment ?: "file"
    } catch (_: Exception) { u.lastPathSegment ?: "file" }

    private fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val x = re.findAll(a).map { it.value }.toList()
        val y = re.findAll(b).map { it.value }.toList()
        for (i in 0 until minOf(x.size, y.size)) {
            val p = x[i]; val q = y[i]
            val r = if (p[0].isDigit() && q[0].isDigit()) {
                val d = p.toBigInteger().compareTo(q.toBigInteger())
                if (d != 0) d else p.length.compareTo(q.length)
            } else p.compareTo(q)
            if (r != 0) return r
        }
        return x.size.compareTo(y.size)
    }

    private fun sizeOf(u: Uri): Long = try {
        contentResolver.openFileDescriptor(u, "r")?.use { it.statSize } ?: 0L
    } catch (_: Exception) { 0L }

    // ---------------------------------------------------------------- konversi

    private fun convert() {
        if (busy) return
        if (picked.isEmpty()) { status.text = "Pilih file .ts dulu"; return }
        setBusy(true)
        val src = picked.map { it.first }
        val name = picked.first().second.substringBeforeLast('.', "hasil_gabungan")
            .ifBlank { "hasil_gabungan" } + ".mp4"
        status.text = "Memproses (mode remux, tanpa re-encode)..."
        progress.progress = 0

        Thread {
            var outUri: Uri? = null
            var remuxError: Throwable?
            try {
                outUri = newOutput(name)
                remux(src, outUri)
                publishOutput(outUri)
                finish("Selesai: Download/$name")
                return@Thread
            } catch (e: Cancelled) {
                outUri?.let { deleteOutput(it) }
                finish("Dibatalkan")
                return@Thread
            } catch (e: Throwable) {
                Log.w(TAG, "remux gagal", e)
                outUri?.let { deleteOutput(it) }
                remuxError = e
            }
            runOnUiThread { startTransformer(src, name, remuxError) }
        }.start()
    }

    private fun setBusy(b: Boolean) {
        busy = b
        btnPick.isEnabled = !b
        btnConvert.isEnabled = !b
        btnCancel.isEnabled = b
        if (b) { cancelled = false; window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun finish(msg: String, done: Boolean = true) = runOnUiThread {
        if (done && msg.startsWith("Selesai")) progress.progress = 100
        status.text = msg
        setBusy(false)
    }

    // ---------------------------------------------------------------- output (MediaStore)

    private fun newOutput(name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Gagal membuat file di Downloads")
    }

    private fun publishOutput(u: Uri) {
        val v = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        contentResolver.update(u, v, null, null)
    }

    private fun deleteOutput(u: Uri) { try { contentResolver.delete(u, null, null) } catch (_: Exception) {} }

    // ---------------------------------------------------------------- MODE 1: remux

    private val videoOk = setOf("video/avc", "video/hevc", "video/mp4v-es", "video/3gpp")

    private fun remux(src: List<Uri>, outUri: Uri) {
        val total = src.sumOf { sizeOf(it) }.coerceAtLeast(1L)
        var doneBytes = 0L
        var lastPct = -1

        val outPfd = contentResolver.openFileDescriptor(outUri, "rw")
            ?: throw Exception("Tidak bisa membuka file output")
        val muxer = MediaMuxer(outPfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var started = false
        var written = 0
        try {
            val trackMap = LinkedHashMap<String, Int>()
            var offset = 0L
            var buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()

            for ((idx, u) in src.withIndex()) {
                val inPfd = contentResolver.openFileDescriptor(u, "r")
                    ?: throw Exception("Tidak bisa membuka file input")
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(inPfd.fileDescriptor)
                    val sel = LinkedHashMap<Int, String>()
                    val fmts = HashMap<String, MediaFormat>()
                    var anyAudio = false
                    for (i in 0 until ex.trackCount) {
                        val fmt = ex.getTrackFormat(i)
                        val m = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                        if (m.startsWith("video/")) {
                            if (fmts.containsKey("v")) continue
                            if (m !in videoOk) throw Unsupported("video $m")
                            sel[i] = "v"; fmts["v"] = fmt
                        } else if (m.startsWith("audio/")) {
                            anyAudio = true
                            if (m == MediaFormat.MIMETYPE_AUDIO_AAC && !fmts.containsKey("a")) {
                                sel[i] = "a"; fmts["a"] = fmt
                            }
                        }
                    }
                    if (anyAudio && !fmts.containsKey("a")) throw Unsupported("audio bukan AAC")
                    if (sel.isEmpty()) throw Unsupported("tidak ada track video/audio")

                    if (idx == 0) {
                        for (k in listOf("v", "a")) fmts[k]?.let { trackMap[k] = muxer.addTrack(it) }
                        muxer.start(); started = true
                    } else if (fmts.keys != trackMap.keys) {
                        throw Unsupported("susunan track file ke-${idx + 1} berbeda")
                    }

                    sel.keys.forEach { ex.selectTrack(it) }
                    var base = -1L
                    var maxEnd = offset
                    while (true) {
                        if (cancelled) throw Cancelled()
                        val sz = ex.sampleSize
                        if (sz < 0) break
                        if (sz > buf.capacity()) buf = ByteBuffer.allocate(sz.toInt() + 4096)
                        buf.clear()
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        val t = ex.sampleTime
                        val mt = sel[ex.sampleTrackIndex]?.let { trackMap[it] }
                        if (mt != null && t >= 0) {
                            if (base < 0) base = t
                            val pts = maxOf(0L, t - base) + offset
                            val fl = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                                MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                            info.set(0, size, pts, fl)
                            muxer.writeSampleData(mt, buf, info)
                            written++
                            if (pts > maxEnd) maxEnd = pts
                        }
                        doneBytes += size
                        val pct = (doneBytes * 100 / total).toInt().coerceIn(0, 99)
                        if (pct != lastPct) { lastPct = pct; runOnUiThread { progress.progress = pct } }
                        ex.advance()
                    }
                    offset = maxEnd + 33_333L
                } finally {
                    try { ex.release() } catch (_: Exception) {}
                    try { inPfd.close() } catch (_: Exception) {}
                }
            }
            if (written == 0) throw Unsupported("tidak ada sample yang terbaca")
            muxer.stop()
            started = false
        } finally {
            try { muxer.release() } catch (_: Exception) {}
            try { outPfd.close() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------- MODE 2: Media3 Transformer

    private fun startTransformer(src: List<Uri>, name: String, remuxError: Throwable?) {
        if (cancelled) { finish("Dibatalkan"); return }
        val tmp = File(cacheDir, "hasil_gabungan.mp4").also { if (it.exists()) it.delete() }
        status.text = "Remux tidak bisa (${remuxError?.message}). Mencoba mode Transformer..."
        progress.progress = 0
        try {
            val items = src.map { EditedMediaItem.Builder(MediaItem.fromUri(it)).build() }
            val composition = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
            val t = Transformer.Builder(this)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        handler.removeCallbacksAndMessages(null)
                        status.text = "Menyimpan ke Downloads..."
                        Thread {
                            var out: Uri? = null
                            try {
                                out = newOutput(name)
                                contentResolver.openOutputStream(out, "w")!!.use { o ->
                                    tmp.inputStream().use { it.copyTo(o) }
                                }
                                publishOutput(out)
                                tmp.delete()
                                finish("Selesai: Download/$name")
                            } catch (e: Exception) {
                                out?.let { deleteOutput(it) }
                                finish("Gagal simpan: ${chain(e)}")
                            }
                        }.start()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        handler.removeCallbacksAndMessages(null)
                        tmp.delete()
                        if (cancelled) { finish("Dibatalkan"); return }
                        finish("Gagal. Remux: ${remuxError?.let { chain(it) }} | Transformer: ${chain(exportException)}")
                    }
                }).build()
            transformer = t
            status.text = "Memproses (mode Transformer)..."
            t.start(composition, tmp.absolutePath)
            val holder = ProgressHolder()
            handler.post(object : Runnable {
                override fun run() {
                    if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED)
                        progress.progress = holder.progress
                    handler.postDelayed(this, 300)
                }
            })
        } catch (e: Throwable) {
            finish("Gagal: ${chain(e)}")
        }
    }

    private fun chain(t: Throwable): String =
        generateSequence(t) { it.cause }.joinToString(" <- ") { "${it.javaClass.simpleName}: ${it.message}" }

    // ---------------------------------------------------------------- crash logger

    private fun installCrashLogger() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            try { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(e)) } catch (_: Throwable) {}
            prev?.uncaughtException(th, e)
        }
    }

    private fun showPreviousCrash() {
        try {
            val f = File(filesDir, "crash.txt")
            if (f.exists()) {
                status.text = "Crash sebelumnya:\n" + f.readText().take(1500)
                f.delete()
            }
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AlfyConverter"
        private const val REQ_PICK = 1
    }
}
