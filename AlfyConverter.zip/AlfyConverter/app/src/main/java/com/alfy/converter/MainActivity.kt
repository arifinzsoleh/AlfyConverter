package com.alfy.converter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.Clock
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSourceBitmapLoader
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.transformer.DefaultAssetLoaderFactory
import androidx.media3.transformer.DefaultDecoderFactory
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.nio.ByteBuffer

@UnstableApi
class MainActivity : Activity() {
    private var uris: List<Uri> = emptyList()
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, 1)
        }
        findViewById<Button>(R.id.btnConvert).setOnClickListener { convert() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return
        val list = mutableListOf<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) list.add(c.getItemAt(i).uri) }
            ?: data.data?.let { list.add(it) }
        list.forEach { u -> try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
        uris = list.sortedWith(naturalOrder())
        status.text = "${uris.size} file dipilih"
    }

    private fun nameOf(u: Uri): String =
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: u.lastPathSegment ?: ""

    private fun naturalOrder() = Comparator<Uri> { a, b ->
        val re = Regex("\\d+|\\D+")
        val x = re.findAll(nameOf(a)).map { it.value }.toList()
        val y = re.findAll(nameOf(b)).map { it.value }.toList()
        var r = 0
        for (i in 0 until minOf(x.size, y.size)) {
            val p = x[i]; val q = y[i]
            r = if (p[0].isDigit() && q[0].isDigit()) {
                val d = p.toBigInteger().compareTo(q.toBigInteger())
                if (d != 0) d else p.length.compareTo(q.length)
            } else p.compareTo(q)
            if (r != 0) break
        }
        if (r != 0) r else x.size.compareTo(y.size)
    }

    private fun convert() {
        if (uris.isEmpty()) { status.text = "Pilih file .ts dulu"; return }
        status.text = "Menyalin file..."
        val src = uris
        Thread {
            try {
                val local = src.mapIndexed { i, u ->
                    val f = File(cacheDir, "in_$i.ts")
                    contentResolver.openInputStream(u)!!.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    Uri.fromFile(f)
                }
                runOnUiThread { startExport(local) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal baca file: ${e.message}" }
            }
        }.start()
    }

    private fun cleanInputs() { cacheDir.listFiles()?.filter { it.name.startsWith("in_") }?.forEach { it.delete() } }

    private fun startExport(sources: List<Uri>) {
        val out = File(cacheDir, "hasil_gabungan.mp4").also { if (it.exists()) it.delete() }
        val items = sources.map { EditedMediaItem.Builder(MediaItem.fromUri(it)).build() }
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
        val assetLoaderFactory = DefaultAssetLoaderFactory(
            this, DefaultDecoderFactory.Builder(this).build(), Clock.DEFAULT,
            DefaultMediaSourceFactory(DefaultDataSource.Factory(this)),
            DataSourceBitmapLoader(this)
        )
        val t = Transformer.Builder(this)
            .setAssetLoaderFactory(assetLoaderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    cleanInputs()
                    progress.progress = 100
                    status.text = try { "Selesai: Downloads/${saveToDownloads(out)}" } catch (e: Exception) { "Gagal simpan: ${e.message}" }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    handler.removeCallbacksAndMessages(null)
                    status.text = "Transformer gagal, mencoba mode remux..."
                    val files = sources.map { File(it.path!!) }
                    Thread {
                        try {
                            remux(files, out)
                            val msg = try { "Selesai: Downloads/${saveToDownloads(out)}" } catch (e: Exception) { "Gagal simpan: ${e.message}" }
                            runOnUiThread { progress.progress = 100; status.text = msg; cleanInputs() }
                        } catch (e: Exception) {
                            runOnUiThread { cleanInputs(); status.text = "Gagal: ${chain(exportException)} | ${chain(e)}" }
                        }
                    }.start()
                }
            }).build()
        transformer = t
        progress.progress = 0
        status.text = "Memproses..."
        t.start(composition, out.absolutePath)
        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) progress.progress = holder.progress
                handler.postDelayed(this, 300)
            }
        })
    }

    private fun chain(t: Throwable): String =
        generateSequence(t) { it.cause }.joinToString(" <- ") { "${it.javaClass.simpleName}: ${it.message}" }

    private fun remux(files: List<File>, out: File) {
        if (out.exists()) out.delete()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var started = false
        var written = 0
        try {
            val map = HashMap<String, Int>()
            var offset = 0L
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            for ((idx, f) in files.withIndex()) {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(f.absolutePath)
                    val sel = HashMap<Int, String>()
                    for (i in 0 until ex.trackCount) {
                        val fmt = ex.getTrackFormat(i)
                        val m = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                        val key = when {
                            m.startsWith("video/") -> "v"
                            m == "audio/mp4a-latm" -> "a"
                            else -> continue
                        }
                        if (sel.containsValue(key)) continue
                        sel[i] = key
                        if (idx == 0) map[key] = muxer.addTrack(fmt)
                    }
                    if (idx == 0) {
                        if (map.isEmpty()) throw Exception("Tidak ada track video/audio yang didukung")
                        muxer.start(); started = true
                    }
                    sel.keys.forEach { ex.selectTrack(it) }
                    var base = -1L
                    var maxEnd = offset
                    while (true) {
                        buf.clear()
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        val mt = sel[ex.sampleTrackIndex]?.let { map[it] }
                        if (mt != null) {
                            val t = ex.sampleTime
                            if (base < 0) base = t
                            val pts = maxOf(0L, t - base) + offset
                            val fl = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                            info.set(0, size, pts, fl)
                            muxer.writeSampleData(mt, buf, info)
                            written++
                            if (pts > maxEnd) maxEnd = pts
                        }
                        ex.advance()
                    }
                    offset = maxEnd + 33333
                    runOnUiThread { progress.progress = (idx + 1) * 100 / files.size }
                } finally { ex.release() }
            }
            if (written == 0) throw Exception("Tidak ada sample terbaca")
        } finally {
            if (started) try { muxer.stop() } catch (_: Exception) {}
            muxer.release()
        }
    }

    private fun saveToDownloads(src: File): String {
        val name = "hasil_gabungan_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        src.delete()
        return name
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        super.onDestroy()
    }
}
