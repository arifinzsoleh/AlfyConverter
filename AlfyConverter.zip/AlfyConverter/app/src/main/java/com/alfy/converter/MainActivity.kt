package com.alfy.converter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.Clock
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSourceBitmapLoader
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.transformer.DefaultAssetLoaderFactory
import androidx.media3.transformer.DefaultDecoderFactory
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

@UnstableApi
class MainActivity : Activity() {
    private var uris: List<Uri> = emptyList()
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, 1)
        }
        findViewById<Button>(R.id.btnConvert).setOnClickListener { convert() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return
        val list = mutableListOf<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) list.add(c.getItemAt(i).uri) }
            ?: data.data?.let { list.add(it) }
        list.forEach { u -> try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
        uris = list.sortedWith(naturalOrder())
        status.text = "${uris.size} file dipilih"
    }

    private fun nameOf(u: Uri): String =
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: u.lastPathSegment ?: ""

    private fun naturalOrder() = Comparator<Uri> { a, b ->
        val re = Regex("\\d+|\\D+")
        val x = re.findAll(nameOf(a)).map { it.value }.toList()
        val y = re.findAll(nameOf(b)).map { it.value }.toList()
        var r = 0
        for (i in 0 until minOf(x.size, y.size)) {
            val p = x[i]; val q = y[i]
            r = if (p[0].isDigit() && q[0].isDigit()) {
                val d = p.toBigInteger().compareTo(q.toBigInteger())
                if (d != 0) d else p.length.compareTo(q.length)
            } else p.compareTo(q)
            if (r != 0) break
        }
        if (r != 0) r else x.size.compareTo(y.size)
    }

    private fun convert() {
        if (uris.isEmpty()) { status.text = "Pilih file .ts dulu"; return }
        status.text = "Menyalin file..."
        val src = uris
        Thread {
            try {
                val local = src.mapIndexed { i, u ->
                    val f = File(cacheDir, "in_$i.ts")
                    contentResolver.openInputStream(u)!!.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    Uri.fromFile(f)
                }
                runOnUiThread { startExport(local) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal baca file: ${e.message}" }
            }
        }.start()
    }

    private fun cleanInputs() { cacheDir.listFiles()?.filter { it.name.startsWith("in_") }?.forEach { it.delete() } }

    private fun startExport(sources: List<Uri>) {
        val out = File(cacheDir, "hasil_gabungan.mp4").also { if (it.exists()) it.delete() }
        val items = sources.map { EditedMediaItem.Builder(MediaItem.fromUri(it)).build() }
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
        val assetLoaderFactory = DefaultAssetLoaderFactory(
            this, DefaultDecoderFactory.Builder(this).build(), Clock.DEFAULT,
            DefaultMediaSourceFactory(DefaultDataSource.Factory(this)),
            DataSourceBitmapLoader(this)
        )
        val t = Transformer.Builder(this)
            .setAssetLoaderFactory(assetLoaderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    cleanInputs()
                    progress.progress = 100
                    status.text = try { "Selesai: Downloads/${saveToDownloads(out)}" } catch (e: Exception) { "Gagal simpan: ${e.message}" }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    handler.removeCallbacksAndMessages(null)
                    cleanInputs()
                    status.text = "Gagal: ${exportException.errorCodeName} - ${exportException.cause?.message ?: exportException.message}"
                }
            }).build()
        transformer = t
        progress.progress = 0
        status.text = "Memproses..."
        t.start(composition, out.absolutePath)
        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) progress.progress = holder.progress
                handler.postDelayed(this, 300)
            }
        })
    }

    private fun saveToDownloads(src: File): String {
        val name = "hasil_gabungan_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        src.delete()
        return name
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        super.onDestroy()
    }
}
